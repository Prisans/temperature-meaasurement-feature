import React from 'react'
import './App.css'
import Assignment from './Assignment/Assignment'



const App = () => {
  return (
    <div className='container' >
  <Assignment/>
    </div>
  )
}

export default App